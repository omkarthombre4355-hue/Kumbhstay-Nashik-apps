import { NextResponse } from "next/server"; import { prisma } from "@/lib/prisma";
export async function GET(_:Request,{params}:{params:{id:string}}){const hotel=await prisma.hotel.findFirst({where:{id:params.id,approved:true},include:{rooms:{where:{active:true}}}});if(!hotel)return NextResponse.json({error:"Hotel not found"},{status:404});return NextResponse.json(hotel);}
