import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
export async function GET(){return NextResponse.json(await prisma.hotel.findMany({where:{approved:true},include:{rooms:{where:{active:true}}},orderBy:{createdAt:"desc"}}))}
export async function POST(req:Request){const s=await getSession();if(!s||s.role!=="HOTEL_OWNER")return NextResponse.json({error:"Hotel owner login required"},{status:403});const p=z.object({name:z.string().min(2),area:z.string().min(2),address:z.string().min(5),description:z.string().max(2000).optional()}).safeParse(await req.json());if(!p.success)return NextResponse.json({error:"Invalid hotel details"},{status:400});const exists=await prisma.hotel.findUnique({where:{ownerId:s.userId}});if(exists)return NextResponse.json({error:"You already have a hotel profile"},{status:409});const h=await prisma.hotel.create({data:{...p.data,ownerId:s.userId,approved:false,commissionPct:Number(process.env.PLATFORM_COMMISSION_PCT||10)}});return NextResponse.json(h);}
