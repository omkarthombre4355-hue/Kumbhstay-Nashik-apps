import { Resend } from "resend";
import { prisma } from "@/lib/prisma";

async function sendEmail(to:string, subject:string, html:string){
  if(!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) return;
  const resend=new Resend(process.env.RESEND_API_KEY);
  await resend.emails.send({from:process.env.EMAIL_FROM,to,subject,html});
}

async function sendWhatsApp(phone:string, booking:any){
  if(process.env.WHATSAPP_ENABLED!=="true" || !process.env.WHATSAPP_ACCESS_TOKEN || !process.env.WHATSAPP_PHONE_NUMBER_ID || !process.env.WHATSAPP_TEMPLATE_NAME) return;
  const version=process.env.WHATSAPP_API_VERSION || "v23.0";
  const url=`https://graph.facebook.com/${version}/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`;
  const body={messaging_product:"whatsapp",to:phone.replace(/\D/g,""),type:"template",template:{name:process.env.WHATSAPP_TEMPLATE_NAME,language:{code:process.env.WHATSAPP_TEMPLATE_LANGUAGE||"en"},components:[{type:"body",parameters:[{type:"text",text:booking.user.name},{type:"text",text:booking.hotel.name},{type:"text",text:booking.id}]}]}}};
  await fetch(url,{method:"POST",headers:{"Authorization":`Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,"Content-Type":"application/json"},body:JSON.stringify(body)});
}

export async function notifyBookingConfirmed(bookingId:string){
  const b=await prisma.booking.findUnique({where:{id:bookingId},include:{user:true,hotel:true,room:true}});
  if(!b) return;
  const checkIn=b.checkIn.toLocaleDateString("en-IN"), checkOut=b.checkOut.toLocaleDateString("en-IN");
  const html=`<h2>Booking confirmed</h2><p>Hello ${b.user.name},</p><p>Your booking at <b>${b.hotel.name}</b> is confirmed.</p><p>Room: ${b.room.name}<br>Check-in: ${checkIn}<br>Check-out: ${checkOut}<br>Booking ID: ${b.id}<br>Amount: ₹${(b.amountPaise/100).toLocaleString("en-IN")}</p>`;
  try { await sendEmail(b.user.email,"KumbhStay Nashik – Booking confirmed",html); } catch {}
  if(b.user.phone) { try { await sendWhatsApp(b.user.phone,b); } catch {} }
}
