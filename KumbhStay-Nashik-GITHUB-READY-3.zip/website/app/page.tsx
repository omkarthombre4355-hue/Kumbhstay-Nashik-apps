 "use client";
import { useMemo, useState } from "react";
import { Search, MapPin, Star, ShieldCheck, CalendarDays, Users, ChevronRight, Menu, X, Phone } from "lucide-react";

type Hotel={id:number;name:string;area:string;price:number;rating:number;reviews:number;image:string;tags:string[];distance:string};
const hotels:Hotel[]=[
 {id:1,name:"Godavari Riverside Inn",area:"Panchavati",price:2499,rating:4.6,reviews:184,image:"https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80",tags:["Breakfast","Parking","Family"],distance:"1.2 km from Ram Kund"},
 {id:2,name:"Trimbak Heritage Stay",area:"Trimbakeshwar",price:1899,rating:4.4,reviews:121,image:"https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1200&q=80",tags:["Temple Shuttle","Wi-Fi","AC"],distance:"2.1 km from Trimbakeshwar Temple"},
 {id:3,name:"Kumbh Comfort Residency",area:"Nashik Road",price:1599,rating:4.3,reviews:96,image:"https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=80",tags:["Parking","24×7 Desk","AC"],distance:"4.8 km from Nashik Road Station"},
 {id:4,name:"Panchavati Suites",area:"Panchavati",price:3299,rating:4.7,reviews:243,image:"https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=1200&q=80",tags:["Breakfast","River View","Family"],distance:"0.9 km from Ram Kund"}
];

export default function Home(){
 const [q,setQ]=useState(""); const [area,setArea]=useState("All areas"); const [menu,setMenu]=useState(false);
 const [checkin,setCheckin]=useState(""); const [checkout,setCheckout]=useState(""); const [guests,setGuests]=useState("2 Guests");
 const [selected,setSelected]=useState<Hotel|null>(null); const [booked,setBooked]=useState(false);
 const filtered=useMemo(()=>hotels.filter(h=>(area==="All areas"||h.area===area)&&(`${h.name} ${h.area}`.toLowerCase().includes(q.toLowerCase()))),[q,area]);
 const submit=(e:React.FormEvent)=>{e.preventDefault();document.getElementById("hotels")?.scrollIntoView({behavior:"smooth"})};
 return <main>
  <header className="header"><div className="container nav"><div className="brand"><span className="logo">ॐ</span><div><b>KumbhStay</b><small>Nashik</small></div></div>
   <nav className={menu?"mobileNav":""}><a href="#hotels">Hotels</a><a href="#why">Why us</a><a href="#partner">List your hotel</a><a href="#help">Help</a></nav>
   <button className="menuBtn" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button>
  </div></header>

  <section className="hero"><div className="heroOverlay"><div className="container heroInner">
    <div className="pill">Nashik–Trimbakeshwar Simhastha Kumbh</div>
    <h1>Stay closer to the <span>Kumbh.</span></h1>
    <p>Find verified hotels and comfortable stays across Nashik & Trimbakeshwar.</p>
    <form className="searchBox" onSubmit={submit}>
      <label><MapPin/> <span>Destination</span><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Nashik, Panchavati..." /></label>
      <label><CalendarDays/><span>Check-in</span><input type="date" value={checkin} onChange={e=>setCheckin(e.target.value)}/></label>
      <label><CalendarDays/><span>Check-out</span><input type="date" value={checkout} onChange={e=>setCheckout(e.target.value)}/></label>
      <label><Users/><span>Guests</span><select value={guests} onChange={e=>setGuests(e.target.value)}><option>1 Guest</option><option>2 Guests</option><option>3 Guests</option><option>4 Guests</option><option>5+ Guests</option></select></label>
      <button className="searchBtn"><Search/> Search</button>
    </form>
  </div></div></section>

  <section className="container trust"><div><ShieldCheck/><b>Verified stays</b><span>Hotel details reviewed</span></div><div><Phone/><b>Booking support</b><span>Help when you need it</span></div><div><Star/><b>Guest ratings</b><span>Real stay feedback</span></div></section>

  <section id="hotels" className="container section"><div className="sectionHead"><div><p className="eyebrow">DISCOVER YOUR STAY</p><h2>Popular stays in Nashik</h2></div>
    <select value={area} onChange={e=>setArea(e.target.value)} className="filter"><option>All areas</option><option>Panchavati</option><option>Trimbakeshwar</option><option>Nashik Road</option></select>
  </div>
  <div className="grid">{filtered.map(h=><article className="card" key={h.id}><img src={h.image} alt={h.name}/><div className="cardBody"><div className="rating"><Star/> {h.rating} <span>({h.reviews})</span></div><h3>{h.name}</h3><p className="muted"><MapPin/> {h.area} · {h.distance}</p><div className="tags">{h.tags.map(t=><span key={t}>{t}</span>)}</div><div className="priceRow"><div><small>Starting from</small><strong>₹{h.price.toLocaleString("en-IN")}</strong><small>/ night</small></div><button onClick={()=>setSelected(h)}>View rooms <ChevronRight/></button></div></div></article>)}</div>
  {filtered.length===0&&<div className="empty">No stays match your search.</div>}</section>

  <section id="why" className="why"><div className="container"><p className="eyebrow">BOOK WITH CONFIDENCE</p><h2>Made for Kumbh travellers</h2><div className="whyGrid"><div><b>📍 Location-first</b><p>Search by Nashik areas and key pilgrimage landmarks.</p></div><div><b>🛎️ Flexible stays</b><p>Room details, policies and guest requirements in one place.</p></div><div><b>🔒 Transparent booking</b><p>Clear pricing and a simple booking flow without hidden surprises.</p></div></div></div></section>

  <section id="partner" className="partner"><div className="container partnerBox"><div><p className="eyebrow">HOTEL OWNERS</p><h2>Get more Kumbh bookings</h2><p>List your property and manage rooms, rates and enquiries from one place.</p></div><a href="mailto:partners@kumbhstaynashik.example">Become a partner <ChevronRight/></a></div></section>

  <footer id="help"><div className="container footer"><div><div className="brand"><span className="logo">ॐ</span><div><b>KumbhStay</b><small>Nashik</small></div></div><p>Independent hotel-booking starter for Nashik & Trimbakeshwar.</p></div><div><b>Quick links</b><a href="#hotels">Hotels</a><a href="#partner">List your hotel</a><a href="#why">Why us</a></div><div><b>Support</b><span>Booking help</span><span>Partner support</span><span>Policies</span></div></div><div className="copyright">© 2026 KumbhStay Nashik · Demo starter — connect your own backend before accepting live payments.</div></footer>

  {selected&&<div className="modalBack" onClick={()=>setSelected(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><img src={selected.image} alt=""/><div className="modalContent"><div className="rating"><Star/> {selected.rating} ({selected.reviews})</div><h2>{selected.name}</h2><p className="muted">{selected.area} · {selected.distance}</p><div className="room"><div><b>Deluxe AC Room</b><p>2 guests · Breakfast optional · Free Wi-Fi</p></div><strong>₹{selected.price.toLocaleString("en-IN")}<small>/night</small></strong></div><button className="primary" onClick={()=>setBooked(true)}>Request booking</button>{booked&&<div className="success">Booking request captured in this demo. Connect a backend/payment gateway for live reservations.</div>}</div></div></div>}
 </main>
}