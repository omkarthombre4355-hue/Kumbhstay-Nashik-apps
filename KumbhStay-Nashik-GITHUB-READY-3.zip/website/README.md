# KumbhStay Nashik V4 — Production Deployment Package

## Stack
Next.js App Router + TypeScript + Prisma + Supabase PostgreSQL + Vercel + Razorpay + Resend + WhatsApp Cloud API.

## Included
- Supabase/PostgreSQL Prisma schema
- Vercel build/deploy config + protected cleanup cron
- Customer registration/login
- Hotel-owner registration + hotel onboarding
- Customer hotel booking UI
- Razorpay TEST/LIVE environment switch
- Razorpay order creation, callback signature verification and webhook verification
- Customer booking history + confirmation page
- Email booking confirmation through Resend
- WhatsApp template notification through Meta WhatsApp Cloud API
- Owner dashboard and room inventory
- Admin approval, commission and payout ledger
- Demo seed

## 1. Supabase
Create a Supabase project and obtain PostgreSQL connection strings. For Prisma on serverless deployments, use the Supavisor transaction/session pooler appropriately; keep a migration/direct URL as recommended by Supabase. See official docs:
https://supabase.com/docs/guides/database/prisma

Set:
DATABASE_URL=...
DIRECT_URL=...

Then:
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed

## 2. Local environment
Copy `.env.example` to `.env.local` and fill values.

Generate secrets, for example:
openssl rand -base64 32

Never commit `.env.local`, Razorpay secret, WhatsApp token, or Resend API key.

## 3. Razorpay
Start with:
RAZORPAY_MODE=test
RAZORPAY_KEY_ID=rzp_test_...
RAZORPAY_KEY_SECRET=...
NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_test_...
RAZORPAY_WEBHOOK_SECRET=...

Configure webhook:
https://YOUR-DOMAIN.com/api/payments/webhook

Test end-to-end before switching to `rzp_live_...`.

The backend verifies the Checkout signature and the webhook HMAC. Razorpay recommends keeping API secrets out of client builds and validating callback/webhook signatures.

## 4. Email
Create a Resend account, verify the sending domain, then set:
RESEND_API_KEY=...
EMAIL_FROM=KumbhStay Nashik <bookings@yourdomain.com>

## 5. WhatsApp
Create a Meta WhatsApp Business / Cloud API setup, obtain the phone number ID and access token, and create/approve a message template named in `WHATSAPP_TEMPLATE_NAME`.
Set `WHATSAPP_ENABLED=true`.

The included sender uses a template with:
1. customer name
2. hotel name
3. booking ID

Adapt the template/component parameters to the exact approved template in your Meta account.

## 6. Vercel
Push this folder to GitHub, import the repository in Vercel, and add all production environment variables under Project Settings -> Environment Variables.
Build command is `npm run build`.

After deployment:
- Set `NEXT_PUBLIC_APP_URL` to your real HTTPS domain.
- Set Razorpay webhook to `/api/payments/webhook`.
- Verify email domain and WhatsApp template.
- Run a real test booking in TEST mode.

## 7. Live switch
Only after TEST mode works:
- replace `rzp_test_` values with the activated `rzp_live_` values
- change `RAZORPAY_MODE=live`
- keep the secret only in Vercel server environment variables
- re-test webhook delivery and booking confirmation

## 8. Production checklist
- PostgreSQL backups and monitoring
- Unique/idempotent payment processing
- booking concurrency protection for high-demand dates
- cancellation/refund rules
- GST/tax invoice logic
- hotel KYC and bank verification
- payout reconciliation
- privacy policy, terms, cancellation policy and consumer disclosures
- rate limiting, CSRF/origin protection, audit logs
- secure admin 2FA and least-privilege access
- error monitoring
- real hotel photos/content and verified inventory
- domain/DNS/HTTPS

This package is deployment-ready engineering code, not an already deployed commercial service. Live operation still requires your own Supabase, Vercel, Razorpay, email, WhatsApp credentials and business/legal setup.
