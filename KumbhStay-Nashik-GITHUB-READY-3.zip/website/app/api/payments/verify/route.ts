import { NextResponse } from "next/server";
import crypto from "crypto";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { notifyBookingConfirmed } from "@/lib/notifications";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Login required" }, { status: 401 });
  const { bookingId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  const booking = await prisma.booking.findFirst({ where: { id: bookingId, userId: session.userId } });
  if (!booking || booking.razorpayOrderId !== razorpay_order_id) return NextResponse.json({ error: "Booking/order mismatch" }, { status: 400 });

  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET!)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
  if (expected !== razorpay_signature) return NextResponse.json({ error: "Invalid payment signature" }, { status: 400 });

  await prisma.$transaction([
    prisma.booking.update({ where: { id: booking.id }, data: { status: "PAID", paymentStatus: "PAID", razorpayPaymentId: razorpay_payment_id } }),
    prisma.payment.update({ where: { bookingId: booking.id }, data: { paymentId: razorpay_payment_id, signature: razorpay_signature, status: "PAID" } })
  ]);

  await notifyBookingConfirmed(booking.id);
  return NextResponse.json({ ok: true });
}
