import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
export async function GET(req:Request){const auth=req.headers.get("authorization");if(auth!==`Bearer ${process.env.CRON_SECRET}`)return new NextResponse("Unauthorized",{status:401});const cutoff=new Date(Date.now()-15*60*1000);const result=await prisma.booking.updateMany({where:{status:"PENDING",paymentStatus:"CREATED",createdAt:{lt:cutoff}},data:{status:"EXPIRED"}});return NextResponse.json({expired:result.count});}
