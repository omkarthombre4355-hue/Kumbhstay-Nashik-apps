"use client";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
export default function BookingSuccess() { const sp=useSearchParams(); const id=sp.get("id"); const [b,setB]=useState<any>(null); useEffect(()=>{fetch("/api/bookings").then(r=>r.json()).then(x=>setB(x.find((a:any)=>a.id===id)));},[id]); return <main className="container"><div className="card"><h1>Booking confirmed 🎉</h1><p>Your payment has been verified.</p>{b&&<><p><b>Booking ID:</b> {b.id}</p><p><b>Hotel:</b> {b.hotel.name}</p><p><b>Room:</b> {b.room.name}</p><p><b>Status:</b> {b.status}</p></>}<a href="/account">View my bookings</a></div></main>; }
