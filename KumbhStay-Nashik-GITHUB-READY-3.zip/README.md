# KumbhStay Nashik — GitHub Ready Full Platform

This is the final repository-ready source package for the KumbhStay Nashik project, with **no Vercel configuration**.

## Repository structure

```text
Kumbhstay-Nashik-apps/
├── website/                    # Next.js website + booking backend/API + Prisma
├── KumbhStay-Customer/         # Customer Android app
├── KumbhStay-HotelOwner/       # Hotel owner Android app
├── KumbhStay-Company/          # Company/Admin Android app
├── .github/workflows/          # One CI workflow for website + all APKs
├── .gitignore
└── README.md
```

## IMPORTANT: GitHub upload

**Do not upload this ZIP file itself into GitHub.**

1. Download this ZIP to your phone/computer.
2. Extract/unzip it.
3. Open the extracted folder.
4. Upload the **contents of the extracted folder** to the root of your `Kumbhstay-Nashik-apps` GitHub repository.
5. After upload, the repository root must directly show `website`, `KumbhStay-Customer`, `KumbhStay-HotelOwner`, `KumbhStay-Company`, `.github`, and `README.md`.
6. Commit directly to the `main` branch.

Do not create an extra outer folder such as `KumbhStay-Nashik-FULL-COMPLETE-no-Vercel/` inside the repository.

## GitHub Actions

After the files are committed, open **Actions → KumbhStay Full Platform Build**. It can run automatically on a push to `main`, or manually with **Run workflow**.

The workflow builds:
- Website + backend
- Customer debug APK
- Hotel Owner debug APK
- Company/Admin debug APK
- A source ZIP artifact

## Website/backend

The `website/` project contains the earlier booking architecture: authentication, hotels, bookings, owner/admin APIs, Prisma schema, Razorpay hooks, and notifications.

Live operation still requires your own database, payment, and notification credentials in `website/.env`. **Never commit secrets.**

No Vercel configuration is included.

## Android apps

The three Android projects are separate Gradle projects and are built by the root GitHub Actions workflow with Java 17, Android 35, and Gradle 8.10.2.

## Current scope

This package combines the previously created website/backend and three Android app projects into one clean GitHub repository structure. The Android apps are currently WebView-based app shells; deeper live API/authentication integration still requires connecting them to the deployed backend. An iOS/Apple app is not included in this package.
