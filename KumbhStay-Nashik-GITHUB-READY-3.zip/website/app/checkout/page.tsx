"use client";
import Script from "next/script";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

declare global { interface Window { Razorpay: any } }

export default function CheckoutPage() {
  const sp = useSearchParams();
  const hotelId = sp.get("hotelId") || "";
  const roomId = sp.get("roomId") || "";
  const [hotel, setHotel] = useState<any>(null);
  const [form, setForm] = useState({ checkIn: "", checkOut: "", guests: 1, units: 1 });
  const [msg, setMsg] = useState("");

  useEffect(() => {
    fetch(`/api/hotels/${hotelId}`).then(r => r.json()).then(setHotel);
  }, [hotelId]);

  async function pay() {
    setMsg("");
    const r = await fetch("/api/bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ hotelId, roomId, ...form }) });
    const data = await r.json();
    if (!r.ok) { setMsg(data.error || "Booking failed"); return; }
    if (!window.Razorpay) { setMsg("Payment checkout is loading. Please try again."); return; }

    const rz = new window.Razorpay({
      key: data.keyId, amount: data.amount, currency: data.currency,
      name: "KumbhStay Nashik", description: `${hotel?.name || "Hotel"} booking`,
      order_id: data.orderId,
      handler: async (response: any) => {
        const vr = await fetch("/api/payments/verify", { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ bookingId: data.bookingId, ...response }) });
        const vd = await vr.json();
        if (vr.ok) window.location.href = `/booking-success?id=${data.bookingId}`;
        else setMsg(vd.error || "Payment verification failed");
      },
      prefill: {},
      theme: { color: "#7c2d12" },
      modal: { ondismiss: () => setMsg("Payment window closed. Your booking remains pending until payment succeeds.") }
    });
    rz.open();
  }

  const room = hotel?.rooms?.find((x: any) => x.id === roomId);
  return <main className="container">
    <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="afterInteractive" />
    <h1>Complete your booking</h1>
    <div className="card">
      <h2>{hotel?.name || "Loading hotel..."}</h2>
      <p>{hotel?.area} · {room?.name} · ₹{room?.price || 0}/night</p>
      <label>Check-in<input type="date" value={form.checkIn} onChange={e => setForm({...form, checkIn:e.target.value})}/></label>
      <label>Check-out<input type="date" value={form.checkOut} onChange={e => setForm({...form, checkOut:e.target.value})}/></label>
      <label>Guests<input type="number" min="1" value={form.guests} onChange={e => setForm({...form, guests:+e.target.value})}/></label>
      <label>Rooms<input type="number" min="1" value={form.units} onChange={e => setForm({...form, units:+e.target.value})}/></label>
      <button onClick={pay}>Pay securely with Razorpay</button>
      {msg && <p className="error">{msg}</p>}
    </div>
  </main>;
}
