KumbhStay Customer Android app.
Build: gradle clean assembleDebug
Main screen is bundled in app/src/main/assets/index.html.
