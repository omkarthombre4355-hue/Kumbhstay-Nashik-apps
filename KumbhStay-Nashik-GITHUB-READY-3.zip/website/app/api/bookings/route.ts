import { NextResponse } from "next/server";
import { z } from "zod";
import Razorpay from "razorpay";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

const schema = z.object({
  hotelId: z.string(),
  roomId: z.string(),
  checkIn: z.string(),
  checkOut: z.string(),
  guests: z.coerce.number().int().min(1),
  units: z.coerce.number().int().min(1)
});

function nights(a: Date, b: Date) {
  return Math.ceil((b.getTime() - a.getTime()) / 86400000);
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Login required" }, { status: 401 });

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid booking details" }, { status: 400 });

  const { hotelId, roomId, guests, units } = parsed.data;
  const checkIn = new Date(parsed.data.checkIn);
  const checkOut = new Date(parsed.data.checkOut);
  if (!(checkOut > checkIn)) return NextResponse.json({ error: "Check-out must be after check-in" }, { status: 400 });

  const room = await prisma.room.findFirst({ where: { id: roomId, hotelId, active: true }, include: { hotel: true } });
  if (!room || !room.hotel.approved) return NextResponse.json({ error: "Room unavailable" }, { status: 404 });
  if (guests > room.capacity * units) return NextResponse.json({ error: "Guest count exceeds room capacity" }, { status: 400 });

  const overlap = await prisma.booking.aggregate({
    where: {
      roomId, status: { in: ["PENDING", "PAID", "CONFIRMED"] },
      checkIn: { lt: checkOut }, checkOut: { gt: checkIn }
    },
    _sum: { units: true }
  });
  const bookedUnits = overlap._sum.units ?? 0;
  if (bookedUnits + units > room.totalUnits) {
    return NextResponse.json({ error: "Selected room is sold out for these dates" }, { status: 409 });
  }

  const totalPaise = nights(checkIn, checkOut) * room.price * units * 100;
  const commissionPaise = Math.round(totalPaise * (room.hotel.commissionPct / 100));
  const ownerAmountPaise = totalPaise - commissionPaise;

  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key_id || !key_secret) return NextResponse.json({ error: "Razorpay is not configured" }, { status: 500 });

  const razorpay = new Razorpay({ key_id, key_secret });
  const order = await razorpay.orders.create({
    amount: totalPaise, currency: "INR", receipt: `ks_${Date.now()}`,
    notes: { hotelId, roomId, userId: session.userId }
  });

  const booking = await prisma.booking.create({
    data: {
      userId: session.userId, hotelId, roomId, checkIn, checkOut, guests, units,
      amountPaise: totalPaise, commissionPaise, ownerAmountPaise,
      razorpayOrderId: order.id, status: "PENDING", paymentStatus: "CREATED",
      payment: { create: { orderId: order.id, provider: "razorpay" } }
    }
  });

  return NextResponse.json({
    bookingId: booking.id, orderId: order.id, amount: totalPaise,
    currency: "INR", keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID
  });
}

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Login required" }, { status: 401 });
  const bookings = await prisma.booking.findMany({
    where: { userId: session.userId },
    include: { hotel: true, room: true, payment: true },
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json(bookings);
}
