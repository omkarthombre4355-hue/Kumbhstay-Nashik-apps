import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "dev-only-secret-change-me");
export async function setSession(user:{id:string;role:string;name:string;email:string}) {
  const token=await new SignJWT(user).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(secret);
  cookies().set("session",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:60*60*24*7,path:"/"});
}
export async function getSession(){
  const token=cookies().get("session")?.value; if(!token) return null;
  try { return (await jwtVerify(token,secret)).payload as {id:string;role:string;name:string;email:string}; } catch { return null; }
}
export function clearSession(){ cookies().delete("session"); }