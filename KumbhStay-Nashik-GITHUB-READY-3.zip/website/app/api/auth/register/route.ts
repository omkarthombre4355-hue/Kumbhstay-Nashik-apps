import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { signSession } from "@/lib/auth";

const schema=z.object({name:z.string().min(2).max(100),email:z.string().email().transform(v=>v.toLowerCase()),phone:z.string().max(30).optional(),password:z.string().min(8).max(100),role:z.enum(["CUSTOMER","HOTEL_OWNER"]).default("CUSTOMER")});
export async function POST(req:Request){const p=schema.safeParse(await req.json());if(!p.success)return NextResponse.json({error:"Invalid registration details"},{status:400});const {name,email,phone,password,role}=p.data;const exists=await prisma.user.findUnique({where:{email}});if(exists)return NextResponse.json({error:"Email already registered"},{status:409});const passwordHash=await bcrypt.hash(password,12);const user=await prisma.user.create({data:{name,email,phone,passwordHash,role}});await signSession({userId:user.id,role:user.role});return NextResponse.json({ok:true,role:user.role});}
